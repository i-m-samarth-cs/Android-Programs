package com.vrs.edittext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText edit=(EditText)findViewById(R.id.edt);
        EditText pass=(EditText)findViewById(R.id.pass);

        System.out.println(edit);
        System.out.println(pass);
    }
}