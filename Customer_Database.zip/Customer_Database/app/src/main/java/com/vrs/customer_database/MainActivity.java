package com.vrs.customer_database;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SQLiteDatabase sql;
    EditText edid,edname,edmob,edadd,edpin,editsearch;
    Button enter,search = (Button)findViewById(R.id.btn2);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edid=(EditText) findViewById(R.id.cid2);
        editsearch=(EditText) findViewById(R.id.search);
        enter=(Button) findViewById(R.id.btn);

        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sql=openOrCreateDatabase("AndroidDatabase", Context.MODE_PRIVATE,null);
                sql.execSQL("CREATE TABLE IF NOT EXISTS AndroidDatabaseTab(id Integer primary key AUTOINCREMENT NOT NULL,cid VARCHAR,mobile VARCHAR,address VARCHAR,pincode VARCHAR);");
                String id = edid.getText().toString();
                String name = edname.getText().toString();
                String mobile = edmob.getText().toString();
                String address = edadd.getText().toString();
                String pincode = edpin.getText().toString();
                String sql = "INSERT INTO AndroidDatabaseTab (id, name, mobile, address, pincode) VALUES ("
                        + id + ", '" + name + "', '" + mobile + "', '" + address + "', '" + pincode + "');";
                Toast.makeText(getApplicationContext(),"Data Inserted Successfully",Toast.LENGTH_LONG).show();
            }
        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sid = editsearch.getText().toString();
                Cursor cur= sql.rawQuery("select * from AndroidDatabaseTab where (id="+sid+",",null);
                StringBuffer buff=new StringBuffer();
                while(cur.moveToNext()){
                    String cid=cur.getString(1);
                    String name=cur.getString(2);
                    String  mob=cur.getString(3);
                    String addr=cur.getString(4);
                    String pin=cur.getString(5);
                    buff.append(cid+" "+name+" "+mob+" "+addr+" "+pin+"\n");

                    Toast.makeText(getApplicationContext(),buff,Toast.LENGTH_LONG).show();

                }
            }
        });


    }
}