package com.vrs.reversegeocoding;

import androidx.appcompat.app.AppCompatActivity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    String strAdd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Geocoder gc=new Geocoder(this);
        if(gc.isPresent()) {
            List<Address> list;
            try {
                list = gc.getFromLocation(37.42279, 122.08056, 1);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Address add = list.get(0);
            StringBuffer str = new StringBuffer();
            str.append("Name:"+add.getLocality()+"\n");
            str.append("Sub-Area:"+add.getSubAdminArea()+"\n");
            str.append("Country:"+add.getCountryName()+"\n");
            str.append("Country Code:"+add.getCountryCode()+"\n");

            strAdd=str.toString();
        }
        Toast.makeText(getApplicationContext(),"Address:"+strAdd,Toast.LENGTH_LONG).show();
    }
}