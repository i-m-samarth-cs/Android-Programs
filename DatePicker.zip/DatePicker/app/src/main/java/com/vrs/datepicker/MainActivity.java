package com.vrs.datepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DatePicker date;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        date=(DatePicker) findViewById(R.id.date);
        btn=(Button)findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v)
            {
                int month=date.getMonth();
                month=month+1;
                Toast.makeText(getBaseContext(),"Date Selected:"+month+"/"+date.getDayOfMonth()+"/"+date.getYear()+"\n",Toast.LENGTH_LONG).show();
            }
        });
    }
}