package com.vrs.services;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.provider.Settings;
import android.widget.Toast;

import java.security.Provider;

public class MyService extends Service {
    private MediaPlayer media;
    @Override
    public IBinder onBind(Intent in){
        return null;
    }
    @Override
    public void onCreate(){
        Toast.makeText(this,"Service Created",Toast.LENGTH_LONG).show();
    }
    @Override
    public int onStartCommand(Intent in,int flags,int start){
        media = MediaPlayer.create(this, Settings.System.DEFAULT_RINGTONE_URI);
        media.setLooping(true);
        media.start();
        Toast.makeText(this,"Service Started",Toast.LENGTH_LONG).show();
        return START_STICKY;
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        media.stop();
        Toast.makeText(this,"Service Stopped",Toast.LENGTH_LONG).show();
    }

}
