package com.vrs.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class MainActivity extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup contain, Bundle savedInstanceState)
    {
        return inf.inflate(R.layout.fragment_one,contain,false);
    }
}