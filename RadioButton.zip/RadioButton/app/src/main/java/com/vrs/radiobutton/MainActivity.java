package com.vrs.radiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup rg;
    RadioButton rb1,rb2;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            rg=(RadioGroup)findViewById(R.id.rg);
            b1=(Button)findViewById(R.id.btn);
            b1.setOnClickListener(new View.OnClickListener(){

                public void onClick(View v){
                    int select=rg.getCheckedRadioButtonId();
                    rb1=(RadioButton)findViewById(select);
                    Toast.makeText(getApplicationContext(),rb1.getText(),Toast.LENGTH_LONG).show();
                }
            });
        }
    }
