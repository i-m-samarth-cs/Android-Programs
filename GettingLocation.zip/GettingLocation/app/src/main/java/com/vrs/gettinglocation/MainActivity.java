package com.vrs.gettinglocation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Toast;

import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.collect.Maps;
import com.google.firebase.firestore.GeoPoint;

import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
class MapOverlay extends com.google.android.Maps.Overlay{
    public boolean drawCanas(MotionEvent event, Map view){
        if(event.getAction()==-1){
            GeoPoint p=view.getProjection().fromPixels((int)event.getX(),(int)event.getX());
            Toast.makeText(this,p.getLatitude()+1E6+","+p.getLongitude()+1E6+","Toast.LENGTH_LONG).show());

        }
        return false;
    }

}