package com.vrs.audiocapture;

import static android.media.MediaRecorder.OutputFormat.THREE_GPP;
import static androidx.core.content.PackageManagerCompat.LOG_TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.icu.text.AlphabeticIndex;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    String filename= Environment.getExternalStorageDirectory().getAbsolutePath()+ File.separator+"new.mp3";
    MediaRecorder mRec;
    MediaPlayer mplay;
    private AlphabeticIndex.Record mrecord=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @SuppressLint("RestrictedApi")
    private void startPlaying(){
        mplay=new MediaPlayer();
        try{
            mplay.setDataSource(filename);
        } catch (IOException e) {
            Log.e(LOG_TAG,"prepare() failed");
        }
    }
    private void stopPlaying(){
        mplay.release();
        mplay=null;
    }
    @SuppressLint("RestrictedApi")
    private void startRecording(){
        mRec=new MediaRecorder();
        mRec.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRec.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRec.setOutputFile(filename);
        mRec.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try{
            mRec.prepare();
        }
        catch(IOException e){
            Log.e(LOG_TAG,"prepare() failed");
        }
        mRec.start();
    }
    private void stopRecording()
    {
        mRec.stop();
        mRec.release();
        mRec=null;
    }

}