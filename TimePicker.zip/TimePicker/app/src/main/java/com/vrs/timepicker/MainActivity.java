package com.vrs.timepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    TimePicker times;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=(TextView)findViewById(R.id.txt);
        times=(TimePicker) findViewById(R.id.time);
        times.setIs24HourView(false);
        int hourOfDay = times.getHour();
        int minute=times.getMinute();
        times.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                Toast.makeText(getApplicationContext(),hourOfDay+" "+minute,Toast.LENGTH_LONG).show();
                txt.setText("Time is :"+hourOfDay+":"+minute);
            }
        });
    }
}