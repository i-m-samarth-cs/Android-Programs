package com.vrs.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView simp;
    String country[]={"India","China","Australia","Portugal","America"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        simp=(ListView)findViewById(R.id.imgv);
        ArrayAdapter <String> adpt=new ArrayAdapter<String>(this,R.layout.activity_main,R.id.txt,country);
        simp.setAdapter(adpt);
    }
}