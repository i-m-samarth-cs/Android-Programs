package com.vrs.sensors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private SensorManager mgr;
    private TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mgr=(SensorManager) getSystemService(Context.SENSOR_SERVICE);
        txt=(TextView) findViewById(R.id.sensor);

        List<Sensor> sens=mgr.getSensorList(Sensor.TYPE_ALL);
        StringBuilder str=new StringBuilder();
        for(Sensor s:sens){
            str.append(s.getName()+"\n");
        }
        txt.setVisibility(View.VISIBLE);
        txt.setText(str);
    }
}