package com.vrs.bluetooth;

import static android.widget.Toast.LENGTH_LONG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Set;

public class MainActivity<btArray> extends AppCompatActivity {
    Button on, off, list, find;
    ListView lst;
    BluetoothAdapter adpt;
    Set<BluetoothDevice> paired;
    ArrayAdapter<String> btarray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        on = (Button) findViewById(R.id.btn1);
        off = (Button) findViewById(R.id.btn2);
        list = (Button) findViewById(R.id.btn3);
        find = (Button) findViewById(R.id.btn4);

        lst = (ListView) findViewById(R.id.lst);

        adpt = BluetoothAdapter.getDefaultAdapter();
        on.setOnClickListener(new View.OnClickListener() {
                                  @Override
                                  public void onClick(View view) {
                                      if (!adpt.isEnabled()) {
                                          Intent in = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                                          if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                                              // TODO: Consider calling
                                              //    ActivityCompat#requestPermissions
                                              // here to request the missing permissions, and then overriding
                                              //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                              //                                          int[] grantResults)
                                              // to handle the case where the user grants the permission. See the documentation
                                              // for ActivityCompat#requestPermissions for more details.
                                              return;
                                          }
                                          startActivity(in);
                                          Toast.makeText(getApplicationContext(), "Turned ON", LENGTH_LONG).show();
                                      } else {
                                          Toast.makeText(getApplicationContext(), "Already ON", LENGTH_LONG).show();
                                      }
                                  }

                              });
                off.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        adpt.disable();
                        Toast.makeText(getApplicationContext(), "Turned OFF", LENGTH_LONG).show();
                    }
                });

        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent vis = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                startActivityForResult(vis);
            }

            private void startActivityForResult(Intent vis) {

            }
        });
        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                paired = adpt.getBondedDevices();
                ListView list=(ListView) findViewById(R.id.lst);
                for(BluetoothDevice bt:paired){
                    list.add(bt.getName());
                }
                Toast.makeText(getApplicationContext(),"Showing Paired Devices",LENGTH_LONG).show();
                ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.lst);
                list.setAdapter(arrayAdapter);
            }
        });
}
}