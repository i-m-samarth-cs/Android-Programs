package com.vrs.togglebutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ToggleButton tg1 = (ToggleButton) findViewById(R.id.tg1);
        ToggleButton tg2 = (ToggleButton) findViewById(R.id.tg2);

        tg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Up Icon Button", Toast.LENGTH_LONG).show();
            }
        });
        tg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Down Icon Button", Toast.LENGTH_LONG).show();
            }
        });
    }
}