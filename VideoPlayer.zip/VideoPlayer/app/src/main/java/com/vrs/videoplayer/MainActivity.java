package com.vrs.videoplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        VideoView vid=(VideoView) findViewById(R.id.vid);
        MediaController media=new MediaController(this);
        media.setAnchorView(vid);

        Uri uri=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.video);
        vid.setMediaController(media);
        vid.setVideoURI(uri);
        vid.requestFocus();
        vid.start();
    }
}