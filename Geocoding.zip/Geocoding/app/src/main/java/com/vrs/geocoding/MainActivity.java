package com.vrs.geocoding;

import androidx.appcompat.app.AppCompatActivity;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    double lat,lang;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Geocoder gc=new Geocoder(this);
        if(gc.isPresent()){
            List<Address> list= null;
            try {
                list = gc.getFromLocationName("Shital Colony Sakri Road Dhule",1);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Address add=list.get(0);
            lat=add.getLatitude();
            lang=add.getLongitude();

        }
        Toast.makeText(getApplicationContext(),"Latitude="+lat+" Longitude="+lang ,Toast.LENGTH_LONG).show();
    }

}