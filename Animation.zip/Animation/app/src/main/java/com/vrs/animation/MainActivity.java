package com.vrs.animation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView img=(ImageView) findViewById(R.id.img);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void clockwise(View view){

        Animation anim= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.myanim);
        img.startAnimation(anim);
    }
    public void zoom(View view){
        img=(ImageView)findViewById(R.id.img);
        Animation anim1=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.clockwise);
        img.startAnimation(anim1);
    }
    public void fade(View view){
        img=(ImageView)findViewById(R.id.img);
        Animation anim1=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fade);
        img.startAnimation(anim1);
    }
    public void blink(View view){
        img=(ImageView)findViewById(R.id.img);
        Animation anim1=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.blink);
        img.startAnimation(anim1);
    }
    public void move(View view){
        img=(ImageView)findViewById(R.id.img);
        Animation anim1=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.move);
        img.startAnimation(anim1);
    }
    public void slide(View view){
        img=(ImageView)findViewById(R.id.img);
        Animation anim1=AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide);
        img.startAnimation(anim1);
    }

}