package com.vrs.checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CheckBox ck1,ck2,ck3;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        addListenerOnbtn();
    }

    private void addListenerOnbtn() {
        ck1=(CheckBox)findViewById(R.id.chk1);
        ck2=(CheckBox)findViewById(R.id.chk2);
        ck3=(CheckBox)findViewById(R.id.chk3);

        btn=(Button)findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StringBuffer res=new StringBuffer();
                res.append("Ios is Checked:").append(ck1.isChecked());
                res.append("Windows is Checked:").append(ck2.isChecked());
                res.append("Android is Checked:").append(ck3.isChecked());

                Toast.makeText(getApplicationContext(),res.toString(),Toast.LENGTH_LONG).show();

            }
        });
    }


}