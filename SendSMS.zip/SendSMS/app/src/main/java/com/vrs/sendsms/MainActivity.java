package com.vrs.sendsms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText mob=(EditText) findViewById(R.id.edt);
        EditText msg=(EditText) findViewById(R.id.edt2);
        Button btn=(Button)findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    SmsManager sms=SmsManager.getDefault();
                    sms.sendTextMessage(mob.getText().toString(),null,msg.getText().toString(),null,null);
                    Toast.makeText(MainActivity.this,"SMS Sent Successfully",Toast.LENGTH_LONG).show();
                }
                catch(Exception e)
                {
                    Toast.makeText(MainActivity.this,"SMS Failed to Send, Please Try Again",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}