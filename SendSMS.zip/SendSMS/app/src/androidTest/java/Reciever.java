import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class Reciever extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent in) {
        if(in.getAction().equals("com.example.MESSAGE_RECIEVED")){
            String msg=in.getString("message");
            Log.d(String.valueOf(this),"Recieved Message:"+msg);
        }
    }
}
