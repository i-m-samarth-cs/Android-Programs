package com.vrs.autocompletetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {
    AutoCompleteTextView actv;
    String arr[]={"Paris,France","PA,United States","Parana,Brazil","Pune,India","Padva,Italy","Pasadena,United States"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        actv=(AutoCompleteTextView)findViewById(R.id.actv);

        ArrayAdapter <String> adpt=new ArrayAdapter<String>(this,android.R.layout.select_dialog_item,arr);
        actv.setThreshold(2);
        actv.setAdapter(adpt);


    }
}