package com.vrs.customtoast;

import static android.view.View.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button click;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        click = (Button) findViewById(R.id.button);
        click.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                showCustomAlert();
            }
        });
    }

    private void showCustomAlert() {
        Context context = getApplicationContext();
        LayoutInflater inflater = getLayoutInflater();

        View toast = inflater.inflate(R.layout.activity_main, null);

        Toast toast1 = new Toast(context);

        toast1.setView(toast);
        toast1.setGravity(Gravity.CENTER_HORIZONTAL, 0, 0);
        toast1.setDuration(Toast.LENGTH_LONG);
        toast1.show();
    }

}


