package com.vrs.databasefile;

import static android.database.sqlite.SQLiteDatabase.CREATE_IF_NECESSARY;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt = (TextView) findViewById(R.id.hi);
        SQLiteDatabase sdb;
        sdb=openOrCreateDatabase("Database db", Context.MODE_PRIVATE,null);
        sdb.setVersion(1);
        sdb.setLocale(Locale.getDefault());
        sdb.setLockingEnabled(true);
        Cursor cur=sdb.query("tab1",null,null,null,null,null,null);
        cur.moveToFirst();
        while(cur.isAfterLast()==false){
            txt.append("/n"+cur.getString(1));
            cur.moveToNext();
        }
        cur.close();

    }
}