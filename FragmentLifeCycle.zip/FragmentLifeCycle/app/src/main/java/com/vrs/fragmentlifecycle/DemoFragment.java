package com.vrs.fragmentlifecycle;

import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class DemoFragment extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        Toast.makeText(getActivity(),"On Create Called",Toast.LENGTH_LONG).show();
    }
    @Override
    public View onCreateView(LayoutInflater inf, ViewGroup contain, Bundle savedInstanceState){
        Toast.makeText(getActivity(),"On Create View",Toast.LENGTH_LONG).show();
        return inf.inflate(R.layout.frag_one,contain,false);
    }

    public void onStart(Bundle savedInstanceState){
        super.onStart();
        Toast.makeText(getActivity(),"On Start View",Toast.LENGTH_LONG).show();
    }
    public void onPause(Bundle savedInstanceState){
        super.onPause();
        Toast.makeText(getActivity(),"On Pause View",Toast.LENGTH_LONG).show();
    }
    public void onStop(Bundle savedInstanceState){
        super.onStop();
        Toast.makeText(getActivity(),"On Stop View",Toast.LENGTH_LONG).show();
    }
    public void onDestroy(Bundle savedInstanceState){
        super.onDestroy();
        Toast.makeText(getActivity(),"On Destroy View",Toast.LENGTH_LONG).show();
    }


}