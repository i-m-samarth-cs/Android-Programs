package com.vrs.broadcast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void broadcastCustom(View v){
        Intent in=new Intent("MyCustomIntent");
        EditText edit=(EditText)findViewById(R.id.edt);
        in.putExtra("Broadcast",(CharSequence)edit.getText().toString());
        in.setAction("com.android.tution.Broadcast.CUSTOM_INTENT");
        sendBroadcast(in);
    }
}