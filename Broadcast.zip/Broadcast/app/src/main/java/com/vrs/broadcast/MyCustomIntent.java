package com.vrs.broadcast;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public abstract class MyCustomIntent extends BroadcastReceiver {

    public void onRecieve(Context arg0, Intent arg1){
        CharSequence in=arg1.getCharSequenceExtra("broadcast");
        Toast.makeText(arg0,"Hello Reader"+in,Toast.LENGTH_LONG).show();
    }
}