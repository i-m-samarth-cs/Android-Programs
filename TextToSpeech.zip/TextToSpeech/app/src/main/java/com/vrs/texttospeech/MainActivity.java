package com.vrs.texttospeech;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {
    Button speak;
    EditText edit;
    TextToSpeech text;
    private Log log;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit=(EditText)findViewById(R.id.edt);
        speak=(Button) findViewById(R.id.btn);
        text=new TextToSpeech(this,this);
        speak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                texttospeech();
            }
        });
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int res = text.setLanguage(Locale.US);
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {

                log.d("error", "language is not supported");

            }
        else
            {
                texttospeech();
            }
        }
        else {
            log.e("error","Failed to Initialize");
        }
    }
    @Override
    public void onDestroy() {
        if(text!=null)
        {
            text.stop();
            text.shutdown();
        }
        super.onDestroy();
    }
    private void texttospeech()
    {
        String txt=speak.getText().toString();
        if("".equals(txt)){
            txt="Please Enter Some text to Speak";
        }
        if(Build.VERSION.SDK_INT==Build.VERSION_CODES.LOLLIPOP){
           text.speak(txt,TextToSpeech.QUEUE_FLUSH,null,null);
    }
        else {
            text.speak(txt,TextToSpeech.QUEUE_FLUSH,null);
        }
    }
}