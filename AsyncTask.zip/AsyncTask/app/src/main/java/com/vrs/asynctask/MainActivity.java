package com.vrs.asynctask;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.AsyncTaskLoader;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.BreakIterator;
import java.text.StringCharacterIterator;

public class AsyncTaskRunner extends AsyncTask<String,String,String> {
    private String resp;

    ProgressDialog pg;
    private StringCharacterIterator fin_res;

    @Override
    protected String doInBackground(String ...parans){
        publishProgress("Sleeping....");
        try
        {
            int time=Integer.parseInt(parans[0])*1000;
            Thread.sleep(time);
            resp="Slept for"+parans[0]+"Seconds";
        } catch (InterruptedException e) {
            e.printStackTrace();
            resp=e.getMessage();
        }
        return resp;
    }
    @Override
    protected void onPostExecute(String result){
        pg.dismiss();
        fin_res.setText(result);
    }
    @Override
    protected void onPreExecute(){
        pg=ProgressDialog.show(this,"ProgressDialog","Wait for"+time.getText().toString()+"Seconds");
    }
    @Override
    protected void onProgressUpdate(String ...text){
        fin_res.setText(text[0]);
    }

}
public class MainActivity extends AppCompatActivity {
    Button btn2;
    public EditText time;
    TextView fin_res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        time =(EditText) findViewById(R.id.edit);
        btn2 =(Button) findViewById(R.id.btn);
        fin_res =(TextView) findViewById(R.id.txt2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AsyncTaskRunner run=new AsyncTaskRunner();
                String sleep=time.getText().toString();
                run.execute(sleep);
            }
        });
    }
}

